<?php
echo "

<div class='header clearfix' >
		<img class='header__logo' src='../images/logo_sito2.png'>
		<a href='' class='header__icon-bar'>
			<span></span>
			<span></span>
			<span></span>
		</a>
		<ul class='header__menu animate'>
			<li class='header__menu__item' ><a href='../lib/logout.php' >Logout</a></li>
			<li class='header__menu__item' ><a href='subPages/quizSvolti.php' style='width:200px;'>Vedi quiz svolti</a></li>
			
		</ul>
	</div>
	
	";
?>