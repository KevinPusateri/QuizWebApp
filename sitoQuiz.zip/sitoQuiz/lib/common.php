<?php

	class Conn{
		
		static $DBNAME = "alternanza_lettere";
		static $IPSERVER = "127.0.0.1";
		static $USER = "root";
		static $PASSWORD = "toor130";
	}
?>